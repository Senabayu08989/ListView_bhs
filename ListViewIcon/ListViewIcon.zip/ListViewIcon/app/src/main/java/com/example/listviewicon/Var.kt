package com.example.listviewicon

class Model (val languages:String, val desc:String, val photo:Int)